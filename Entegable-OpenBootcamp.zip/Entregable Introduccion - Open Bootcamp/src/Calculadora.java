public class Calculadora {
    public static void main(String[] args) {
        System.out.println(numeros(7,3,2));

    }
    public static int numeros(int num1,int num2,int num3){
        return(num1+num2+num3);
    }
}
